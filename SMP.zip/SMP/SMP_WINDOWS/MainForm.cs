﻿using PdfiumViewer;
using SHIELD;
using SHIELD.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Threading;
using static SHIELD.KeyboardHook;

namespace SMP_WINDOWS
{
    public partial class MainForm : Form
    {
        #region Fields
        private string filePath;
        private bool data;

        //private string origFilePath;
        //public MainForm(string fileToBeOpened, string orginalFilePath){}

        private string stuLoginId;
        private static bool screenRecoderWarningDisplayed = false;
        static DispatcherTimer timer = null;

        //private bool Key_Alt_PrintScreen = false;
        //private bool Key_PrintScreen = false;

        // for screen detector
        private static bool IsMultiMonitorsFound = false;
        private static bool IsLargeMonitorFound = false;
        DispatcherTimer timerForScreenDetector = null;
        private static int iMaxAllowedScreens = 0;
        private static int iMaxScreenSize = 0;

        // fix for windows+printscreen in window 8.1
        private IntPtr kbh_Handle; // hook
        private HookProc kbh_HookProc; // callback
        #endregion

        #region Properties
        public string fullName { get; set; }
        public string currentPkgPath { get; set; }
        #endregion

        #region constructors
        /*
        public MainForm()
        {
            InitializeComponent();
        }
        */

        public MainForm(string fileToBeOpened)
        {
            InitializeComponent();

            //
            try { this.Icon = Icon.ExtractAssociatedIcon("ic_launcher.ico"); } catch { }

            this.filePath = fileToBeOpened;
            //origFilePath = orginalFilePath;

            //
            if (filePath == null || filePath.Trim().Length == 0)
            {
                //Invalid file and return error
                if (System.Windows.MessageBox.Show
                    ("Unable to play this file. For more information, please contact concerned representative.",
                        "Invalid file") == MessageBoxResult.OK)
                    this.Close();
            }

            pdfViewer1.Renderer.DisplayRectangleChanged += Renderer_DisplayRectangleChanged;
            pdfViewer1.Renderer.ZoomChanged += Renderer_ZoomChanged;

            cutMarginsWhenPrintingToolStripMenuItem.PerformClick();
            //renderToBitmapsToolStripMenuItem.Enabled = false;
            _zoom.Text = pdfViewer1.Renderer.Zoom.ToString();

            // 
            //Closed += Form2_Closed;
            Load += Form2_Load;
            SizeChanged += MainForm_SizeChanged;

            //
            /*
            try
            {
                // Display Student_ID for ONLINE and MAC Address for OFFLINE
                if (!NetworkInterface.GetIsNetworkAvailable())
                    stuLoginId = Utils.GetMACAddress();
                else
                    stuLoginId = DB_Helper.getInstance().getStudentLoginID();
            }
            catch (Exception ex)
            {
            }
            */

            // get App2.Config values
            try
            {
                System.Windows.Application.Current.Dispatcher.BeginInvoke(new Action(() =>
                {
                    iMaxAllowedScreens = Convert.ToInt32(SHIELD.Helpers.AppSettings.GetValueForKey("App2.config", "MaxAllowedScreens"));
                    iMaxScreenSize = /*Convert.ToInt32(SHIELD.Helpers.AppSettings.GetValueForKey("App2.config", "MaxScreenSize"));*/SMP_WINDOWS.DB_Helper.getInstance().getMetaData().Max_Screen_Size;
                }));
            }
            catch (Exception ex)
            {
                //
            }

            //
            System.Windows.Application.Current.Resources["App_Flag_Reading"] = true;
        }
        #endregion

        #region Methods
        private void OpenFile()
        {
            using (var form = new OpenFileDialog())
            {
                form.Filter = "PDF Files (*.pdf)|*.pdf|All Files (*.*)|*.*";
                form.RestoreDirectory = true;
                form.Title = "Open PDF File";

                if (form.ShowDialog(this) != DialogResult.OK)
                {
                    Dispose();
                    return;
                }

                pdfViewer1.Document = PdfDocument.Load(form.FileName);
                //renderToBitmapsToolStripMenuItem.Enabled = false;

            }
        }

        private void FitPage(PdfViewerZoomMode zoomMode)
        {
            int page = pdfViewer1.Renderer.Page;
            pdfViewer1.ZoomMode = zoomMode;
            pdfViewer1.Renderer.Zoom = 1;
            pdfViewer1.Renderer.Page = page;
        }

        // For window resize, move disable
        /*
        protected override void WndProc(ref Message m)
        {
            const int WM_SYSCOMMAND = 0x0112;
            const int SC_MOVE = 0xF010;
            const int WM_NCLBUTTONDBLCLK = 0x00A3; //double click on a title bar a.k.a. non-client area of the form
            
            switch (m.Msg)
            {
                case WM_SYSCOMMAND:             //preventing the form from being moved by the mouse.
                    int command = m.WParam.ToInt32() & 0xfff0;
                    if (command == SC_MOVE)
                        return;
                    break;
            }

            if (m.Msg == WM_NCLBUTTONDBLCLK)       //preventing the form being resized by the mouse double click on the title bar.
            {
                m.Result = IntPtr.Zero;
                return;
            }

            base.WndProc(ref m);
        }
        */

        // Disable PrintScreen / Alt + PrintScreen
        private enum HotKeyModifires
        {
            None = 0x0000, // None
            Alt = 0x0001, // MOD_ALT
            Control = 0x0002, // MOD_CONTROL
            NOREPEAT = 0x4000, // MOD_NOREPEAT
            Shift = 0x0004, // MOD_SHIFT
            Windows = 0x0008 // MOD_WIN
        }

        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifires, int vk);

        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private void RegisterHotKey()
        {
            try
            {
                //HotKeyModifires mods = default(HotKeyModifires);

                //mods = HotKeyModifires.Control Or HotKeyModifires.Shift
                //mods = HotKeyModifires.Alt;

                //User Pressed Alt+Print Screen Keys
                //Key_Alt_PrintScreen = RegisterHotKey(this.Handle, 0, Convert.ToInt32(mods), Convert.ToInt32(Keys.PrintScreen));

                //User Pressed PrintScreen Key
                //Key_PrintScreen = RegisterHotKey(this.Handle, 1, Convert.ToInt32(HotKeyModifires.None), Convert.ToInt32(Keys.PrintScreen));

                RegisterHotKey(this.Handle, 0, Convert.ToInt32(HotKeyModifires.None), Convert.ToInt32(Keys.PrintScreen));
                RegisterHotKey(this.Handle, 1, Convert.ToInt32(HotKeyModifires.Alt), Convert.ToInt32(Keys.PrintScreen));
                RegisterHotKey(this.Handle, 2, Convert.ToInt32(HotKeyModifires.Control), Convert.ToInt32(Keys.PrintScreen));
                RegisterHotKey(this.Handle, 3, Convert.ToInt32(HotKeyModifires.NOREPEAT), Convert.ToInt32(Keys.PrintScreen));
                RegisterHotKey(this.Handle, 4, Convert.ToInt32(HotKeyModifires.Shift), Convert.ToInt32(Keys.PrintScreen));
                RegisterHotKey(this.Handle, 5, Convert.ToInt32(HotKeyModifires.Windows), Convert.ToInt32(Keys.PrintScreen));
            }
            catch (Exception ex)
            {

            }
        }

        private void UnregisterHotKey()
        {
            try
            {
                /****** fix for windows+printscreen in window 8.1 *******/
                UnHookKeyboard();
                /****** /fix for windows+printscreen in window 8.1 *******/


                //if (Key_Alt_PrintScreen)
                //Key_Alt_PrintScreen = UnregisterHotKey(this.Handle, 0);
                //if (Key_PrintScreen)
                //Key_PrintScreen = UnregisterHotKey(this.Handle, 1);

                UnregisterHotKey(this.Handle, 0); // alt + printscrn
                UnregisterHotKey(this.Handle, 1); // printscrn
                UnregisterHotKey(this.Handle, 2); // ctrl + printscrn
                UnregisterHotKey(this.Handle, 3); // alt + printscrn
                UnregisterHotKey(this.Handle, 4); // printscrn
                UnregisterHotKey(this.Handle, 5); // ctrl + printscrn
            }
            catch (Exception ex)
            {

            }
        }

        protected override void WndProc(ref System.Windows.Forms.Message m)
        {
            const int WM_HOTKEY = 0x0312;
            switch (m.Msg)
            {
                case WM_HOTKEY:
                    hotKeyPressed(m.WParam.ToInt32());
                    break;
            }
            base.WndProc(ref m);
        }

        private void hotKeyPressed(Int32 id)
        {
            switch (id)
            {
                case 0:
                    Int16 i = 1;
                    //User Pressed Alt+Print Screen Keys (Do No Action)
                    break;
                case 1:
                    Int16 j = 2;
                    //User Pressed PrintScreen Key (Do No Action)
                    break;
            }
        }

        /****** fix for windows+printscreen in window 8.1 *******/
        // callback
        private int LowLevelKeyboardProc(int nCode, int wParam, IntPtr lParam)
        {
            try
            {
                //
                if (nCode < 0)
                {
                    CallNextHookEx(kbh_Handle, nCode, wParam, lParam);
                    return 0;
                }

                //
                if (wParam == WM_KEYDOWN)
                {
                    IntPtr kbdll = lParam;
                    KBDLLHOOKSTRUCT kbdllstruct = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(kbdll, typeof(KBDLLHOOKSTRUCT));
                    if (kbdllstruct.vkCode == VK_SNAPSHOT)
                    {
                        return -1;
                    }
                }
            }
            catch (Exception ex)
            {
                SMP_WINDOWS.Utils.LogFile(ex.Message, ex.ToString(), "");
            }

            //
            return CallNextHookEx(kbh_Handle, nCode, wParam, lParam);
            //return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
        }

        // hook
        public void HookKeyboard()
        {
            try
            {
                // callback
                kbh_HookProc = LowLevelKeyboardProc;

                /**hook**/
                kbh_Handle = SetWindowsHookEx(WH_KEYBOARD_LL, kbh_HookProc, Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]), 0);
                //kbh_Handle = SetWindowsHookEx(WH_KEYBOARD_LL, kbh_HookProc, IntPtr.Zero, 0);

                /*
                if (kbh_Handle != IntPtr.Zero) {
                    //System.Diagnostics.Debug.WriteLine(String.Format("It worked! HookHandle: {0}", kbh_Handle));
                }
                else
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }*/
            }
            catch (Exception ex)
            {
                //System.Diagnostics.Debug.WriteLine(String.Format("ERROR: {0}", ex.Message));
                SMP_WINDOWS.Utils.LogFile(ex.Message, ex.ToString(), "");
            }
        }

        // unhook
        public void UnHookKeyboard()
        {
            try
            {
                if (kbh_Handle != IntPtr.Zero)
                {
                    UnhookWindowsHookEx(kbh_Handle);
                }
            }
            catch (Exception ex)
            {
                //System.Diagnostics.Debug.WriteLine(String.Format("ERROR: {0}", ex.Message));
                SMP_WINDOWS.Utils.LogFile(ex.Message, ex.ToString(), "");
            }
        }
        /****** // fix for windows+printscreen in window 8.1 *******/

        /*
        // avoid window resize
        protected override void WndProc(ref Message m)
        {
            //
            const int WM_SYSCOMMAND = 0x0112;
            const int SC_MOVE = 0xF010;
            const int WM_NCLBUTTONDBLCLK = 0x00A3; //double click on a title bar a.k.a. non-client area of the form
            switch (m.Msg)
            {
                case WM_SYSCOMMAND:             //preventing the form from being moved by the mouse.
                    int command = m.WParam.ToInt32() & 0xfff0;
                    if (command == SC_MOVE)
                        return;
                    break;
            }
            if (m.Msg == WM_NCLBUTTONDBLCLK)       //preventing the form being resized by the mouse double click on the title bar.
            {
                m.Result = IntPtr.Zero;
                return;
            }

            //
            const int WM_HOTKEY = 0x312;
            switch (m.Msg)
            {
                case WM_HOTKEY:
                    hotKeyPressed(m.WParam.ToInt32());
                    break;
            }

            base.WndProc(ref m);
        }
        */

        private void getFileReadingStatus()
        {
            try
            {
                // get reading progress
                MediaRecord mr = DB_Helper.getInstance().getFileReadingStatus(fullName.Replace(currentPkgPath, ""));
                string completedDuration = Convert.ToString(mr.completedDuration).Trim();
                if (completedDuration != "" || completedDuration != "0")
                {
                    _page.Text = completedDuration;
                    int page;
                    if (int.TryParse(_page.Text, out page))
                        pdfViewer1.Renderer.Page = page - 1;
                }
            }
            catch (Exception ex)
            {
                //
            }
        }
        #endregion

        #region Event handlers
        private void MainForm_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                //
                if (WindowState == FormWindowState.Minimized)
                {
                    UnregisterHotKey();
                }
                else
                {
                    /****** fix for windows+printscreen in window 8.1 *******/
                    //kbh_HookProc = LowLevelKeyboardProc;
                    //kbh_Handle = SetWindowsHookEx(WH_KEYBOARD_LL, kbh_HookProc,
                    //    Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]), 0); /**hook**/
                    /****** /fix for windows+printscreen in window 8.1 *******/

                    //
                    RegisterHotKey();
                }
            }
            catch (Exception ex)
            {
                //
            }
        }

        void Renderer_ZoomChanged(object sender, EventArgs e)
        {
            _zoom.Text = pdfViewer1.Renderer.Zoom.ToString();
        }

        void Renderer_DisplayRectangleChanged(object sender, EventArgs e)
        {
            try
            {
                _page.Text = (pdfViewer1.Renderer.Page + 1).ToString();
            }
            catch (Exception ex)
            {
                //   
            }
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            try
            {
                //var args = Environment.GetCommandLineArgs();

                pdfViewer1.Document = PdfDocument.Load(filePath);
                renderToBitmapsToolStripMenuItem.Enabled = false;

                /*if (args.Length > 1)
                {
                    pdfViewer1.Document = PdfDocument.Load(args[1]);
                    renderToBitmapsToolStripMenuItem.Enabled = false;
                }
                else
                {
                    OpenFile();
                }*/

                pdfViewer1.ShowBookmarks = false;
                pdfViewer1.ShowToolbar = false;

                //_showBookmarks.Checked = pdfViewer1.ShowBookmarks;
                //_showToolbar.Checked = pdfViewer1.ShowToolbar;
                //timer_Tick a = new timer_Tick();
                //MemoryStream memStream = new MemoryStream();

                //string html = "<head></head><body>My HTML Layout</body>";
                ////client.convertHtml(html, memStream);
                //ScreenCapture screencapture = new ScreenCapture();

                //data = screencapture.timer_Tick(data);
                //if (data == false)
                //{

                //}

                //
                getFileReadingStatus();
            }
            catch (Exception)
            {

            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void renderToBitmapsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int dpiX;
            int dpiY;

            using (var form = new ExportBitmapsForm())
            {
                if (form.ShowDialog() != DialogResult.OK)
                    return;

                dpiX = form.DpiX;
                dpiY = form.DpiY;
            }

            string path;

            using (var form = new FolderBrowserDialog())
            {
                if (form.ShowDialog(this) != DialogResult.OK)
                    return;

                path = form.SelectedPath;
            }

            var document = pdfViewer1.Document;

            for (int i = 0; i < document.PageCount; i++)
            {
                using (var image = document.Render(i, (int)document.PageSizes[i].Width, (int)document.PageSizes[i].Height, dpiX, dpiY, false))
                {
                    image.Save(Path.Combine(path, "Page " + i + ".png"));
                }
            }
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            pdfViewer1.Renderer.Page--;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            pdfViewer1.Renderer.Page++;
        }

        private void cutMarginsWhenPrintingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cutMarginsWhenPrintingToolStripMenuItem.Checked = true;
            shrinkToMarginsWhenPrintingToolStripMenuItem.Checked = false;

            pdfViewer1.DefaultPrintMode = PdfPrintMode.CutMargin;
        }

        private void shrinkToMarginsWhenPrintingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shrinkToMarginsWhenPrintingToolStripMenuItem.Checked = true;
            cutMarginsWhenPrintingToolStripMenuItem.Checked = false;

            pdfViewer1.DefaultPrintMode = PdfPrintMode.ShrinkToMargin;
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var form = new PrintPreviewDialog())
            {
                form.Document = pdfViewer1.Document.CreatePrintDocument(pdfViewer1.DefaultPrintMode);
                form.ShowDialog(this);
            }
        }

        private void _fitWidth_Click(object sender, EventArgs e)
        {
            FitPage(PdfViewerZoomMode.FitWidth);
        }

        private void _fitHeight_Click(object sender, EventArgs e)
        {
            FitPage(PdfViewerZoomMode.FitHeight);
        }

        private void _fitBest_Click(object sender, EventArgs e)
        {
            FitPage(PdfViewerZoomMode.FitBest);
        }

        private void _page_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;

                int page;
                if (int.TryParse(_page.Text, out page))
                    pdfViewer1.Renderer.Page = page - 1;
            }
        }

        private void _zoom_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;

                float zoom;
                if (float.TryParse(_zoom.Text, out zoom))
                    pdfViewer1.Renderer.Zoom = zoom;
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            pdfViewer1.Renderer.ZoomIn();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            pdfViewer1.Renderer.ZoomOut();
        }

        private void _rotateLeft_Click(object sender, EventArgs e)
        {
            pdfViewer1.Renderer.RotateLeft();
        }

        private void _rotateRight_Click(object sender, EventArgs e)
        {
            pdfViewer1.Renderer.RotateRight();
        }

        /// <summary>
        /// Updating the media table with the latest reading data(total duration of video, viewed duration and review count) while the form is closing.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // get pdf file total pages
            try
            {
                int currentPage = Convert.ToInt32(_page.Text.Trim());
                // move to bottom
                //pdfViewer1.Renderer.SetDisplayRectLocation(
                //    new System.Drawing.Point(0, -pdfViewer1.Renderer.DisplayRectangle.Bottom)
                //);

                {
                    _page.Text = "10000000"; // is assumed max page no 
                    int page;
                    if (int.TryParse(_page.Text, out page))
                        pdfViewer1.Renderer.Page = page - 1;
                }

                int totalPages = Convert.ToInt32(_page.Text.Trim());

                // save to db if db.currentPage < currentPage
                DB_Helper.getInstance().saveFileReadingStatus(fullName.Replace(currentPkgPath, ""), totalPages, currentPage);

                //if (totalPages == currentPage)
                //    System.Windows.MessageBox.Show("You've just finshed reading of this file, \nReading progress will be restarted.",
                //        "Reading progress", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                //
            }

            try { IsMultiMonitorsFound = false; IsLargeMonitorFound = false; } catch { }

            // pdfViewer1.Dispose();
            try { pdfViewer1.Renderer.Dispose(); } catch { }
            try { pdfViewer1.Document.Dispose(); } catch { }

            try { File.Delete(filePath); } catch { }
            try { FoldersNFilesAdapter.isPlayerOrReaderOpened = false; } catch { }

            try { timer.Stop(); } catch { }
            try { timer = null; } catch { }

            try { timerForScreenDetector.Stop(); } catch { }
            try { timerForScreenDetector = null; } catch { }

            //int pageNumber = pdfViewer1.Renderer.Page + 1 ;
            //int totalPages = pdfViewer1.Document.PageCount;

            //int index = origFilePath.LastIndexOf("media\\") + 5;
            //string fileP = origFilePath.Substring(index, (origFilePath.Length - index));
            //DB_Helper.getInstance().UpdateFileReadingData(fileP, totalPages, pageNumber);
            ////DB_Helper.getInstance().GetReadingScore();


            try
            {
                //
                UnregisterHotKey();
            }
            catch (Exception ex)
            {
                //
            }
        }

        /*private void _hideToolbar_Click(object sender, EventArgs e)
        {
            pdfViewer1.ShowToolbar = _showToolbar.Checked;
        }

        private void _hideBookmarks_Click(object sender, EventArgs e)
        {
            pdfViewer1.ShowBookmarks = _showBookmarks.Checked;
        }*/

        private void Form2_Closed(object sender, System.EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                //
            }
        }

        private void Form2_Load(System.Object sender, System.EventArgs e)
        {
            try
            {
                // prevent screen capture : show black screen
                SMP_WINDOWS.Utils.PreventScreenCapture(this.Handle, true);

                /****** fix for windows+printscreen in window 8.1 *******/
                kbh_HookProc = LowLevelKeyboardProc;
                kbh_Handle = SetWindowsHookEx(WH_KEYBOARD_LL, kbh_HookProc,
                    Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]), 0); /**hook**/
                /****** /fix for windows+printscreen in window 8.1 *******/

                //
                RegisterHotKey();


                // timer for screen detector
                timerForScreenDetector = new DispatcherTimer();
                timerForScreenDetector.Interval = TimeSpan.FromSeconds(5);
                timerForScreenDetector.Tick += timerForScreenDetector_Tick;
                timerForScreenDetector.Start();

                // timer for video recorder check
                timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromSeconds(1);
                timer.Tick += timer_Tick;
                timer.Start();
            }
            catch (Exception ex)
            {
                //
            }
        }

        private void timerForScreenDetector_Tick(object sender, EventArgs e)
        {
            try
            {
                //
                timerForScreenDetector.Interval = TimeSpan.FromSeconds(10); // first check is for 5 sec, later it is 10 sec

                //
                IsMultiMonitorsFound = false;
                if (ScreenDetector.GetDesktopMonitorsCount() > iMaxAllowedScreens)
                {
                    IsMultiMonitorsFound = true;
                    return;
                }

                //
                IsLargeMonitorFound = false;
                foreach (var pf in ScreenDetector.GetDesktopMonitorsPhysicalSize())
                {
                    if (ScreenDetector.GetMonitorSizeInMMToInches(pf) > iMaxScreenSize)
                    {
                        IsLargeMonitorFound = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                //
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (pdfViewer1.Document != null)
                {
                    /*Detect Monitor*/
                    /*** check Aero theme ***/
                    if (!SMP_WINDOWS.Utils.checkAeroEnabled() || IsMultiMonitorsFound || IsLargeMonitorFound)
                    {
                        //
                        timerForScreenDetector.Stop();

                        //
                        timer.Stop();
                        pdfViewer1.Visible = false;

                        if (!SMP_WINDOWS.Utils.checkAeroEnabled())
                        {
                            MessageBoxResult result =
                            System.Windows.MessageBox.Show(
                                "Windows Aero theme has to be enabled for content playback." +
"\nTo enable it, follow steps as below." +
"\n1. Right click on 'desktop'" +
"\n2. Select 'Personalize'" +
"\n3. select 'Theme settings'" +
"\n4. Select any of theme under 'Windows Default Themes' / 'Aero Themes'",
"Windows Aero theme disabled!",
                                MessageBoxButton.OK,
                            MessageBoxImage.Stop);
                        }

                        // check multiple monitor 
                        if (IsMultiMonitorsFound)
                        {
                            System.Windows.MessageBox.Show(
                                    "You are running app in multiple monitor(s)\n" +
                                    "Maximum " + iMaxAllowedScreens + " monitor(s) are allolwed\n" +
                                    "Please disconnect others and try again.\n" +
                                    "Player exiting now.",
                                    "multiple monitor(s) detected",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Stop);
                        }

                        // Check Large monitor 
                        if (IsLargeMonitorFound)
                        {
                            System.Windows.MessageBox.Show(
                                    "You are running app in large monitor(s)\n" +
                                    "Maximum " + iMaxScreenSize + " inches monitor(s) are allolwed\n" +
                                    "Please connect to monitor(s) with allowed size and try again.\n" +
                                    "Player exiting now.",
                                    "Large monitor(s) detected",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Stop);
                        }

                        //
                        this.Close();
                        return;
                    }

                    /* check screen recorder  */
                    Dictionary<string, Process> RunningVideoRecorders =
                        CheckvideoForCapturingApps.checkVideoRecorders();
                    if (RunningVideoRecorders.Count > 0)
                    {
                        string sListOfRunningVideoRecorders = String.Join(",\n",
                            RunningVideoRecorders.Select(x => x.Key));

                        timer.Stop();
                        pdfViewer1.Visible = false;
                        //this.ControlBox = false;
                        //screenRecoderWarningDisplayed = true;

                        var result = System.Windows.Forms.MessageBox.Show(
                            "SHIELD detected a screen recording / video capturing application by name\n" +
                            sListOfRunningVideoRecorders +
                            "\nThis needs to be closed while running SHIELD. Do you want to close it ?",
                            "Active Video Recorder", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                        if (result == DialogResult.Yes)
                        {
                            List<string> NotClosedRunningVideoRecorders =
                                CheckvideoForCapturingApps.KillVideoRecordersProcess(RunningVideoRecorders);

                            if (NotClosedRunningVideoRecorders.Count <= 0)
                            {
                                timer.Start();
                                pdfViewer1.Visible = true;
                                //this.ControlBox = true;
                                //screenRecoderWarningDisplayed = false;
                            }
                            else
                            {
                                string sListNotClosedRunningVideoRecorders =
                                    String.Join(",\n", NotClosedRunningVideoRecorders.Select(x => x));

                                System.Windows.MessageBox.Show("SHIELD can't close following video capturing applications\n" +
                                                               sListNotClosedRunningVideoRecorders +
                                                               "\nThis needs to be closed while running SHIELD.\n" +
                                                               "Please close manually, SHIELD player is exiting.",
                                    "Video Recorders not closed");

                                //screenRecoderWarningDisplayed = false;
                                this.Close();
                                return;
                            }
                        }
                        //else if (result == DialogResult.No)
                        //{
                        //    //screenRecoderWarningDisplayed = false;
                        //    this.Close();
                        //    return;
                        //}
                        else
                        {
                            this.Close();
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                try
                {
                    Utils.LogFile(ex.Message, ex.ToString(), "");
                    this.Close();
                }
                catch { }
            }
        }
        
        #endregion
    }
}
